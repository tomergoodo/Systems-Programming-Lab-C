#include "set.h"
#include "input.h"
#include "info.h"

set SETA = { 0 };
set SETB = { 0 };
set SETC = { 0 };
set SETD = { 0 };
set SETE = { 0 };
set SETF = { 0 };

int main() {

	char operand[MAX_LINE];
	while (TRUE) {
		command_input(operand);
	}
	return 0;

}